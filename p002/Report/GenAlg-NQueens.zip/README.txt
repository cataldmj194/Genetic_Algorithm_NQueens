To compile and run my Genetic Algorithm for NQueens,
issue the following commands:

javac GANQueens.java Creature.java

java GANqueens

To run the program 25 times use:
./run.sh


